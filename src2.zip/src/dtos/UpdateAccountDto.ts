// src/dtos/UpdateAccountDto.ts
import { CreateAccountDto } from './CreateAccountDto';

export class UpdateAccountDto extends CreateAccountDto {}
