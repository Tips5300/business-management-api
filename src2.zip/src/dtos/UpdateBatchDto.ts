import { CreateBatchDto } from './CreateBatchDto';

export class UpdateBatchDto extends CreateBatchDto {}