// src/dtos/UpdateDepartmentDto.ts
import { CreateDepartmentDto } from './CreateDepartmentDto';

export class UpdateDepartmentDto extends CreateDepartmentDto {}
