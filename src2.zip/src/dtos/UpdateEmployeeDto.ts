// src/dtos/UpdateEmployeeDto.ts
import { CreateEmployeeDto } from './CreateEmployeeDto';

export class UpdateEmployeeDto extends CreateEmployeeDto {}
