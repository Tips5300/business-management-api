// src/dtos/UpdateExpenseDto.ts
import { CreateExpenseDto } from './CreateExpenseDto';

export class UpdateExpenseDto extends CreateExpenseDto {}