// src/dtos/UpdateExpenseTypeDto.ts
import { CreateExpenseTypeDto } from './CreateExpenseTypeDto';

export class UpdateExpenseTypeDto extends CreateExpenseTypeDto {}