// src/dtos/UpdateJournalEntryDto.ts
import { CreateJournalEntryDto } from './CreateJournalEntryDto';

export class UpdateJournalEntryDto extends CreateJournalEntryDto {}
