// src/dtos/UpdateLeaveRequestDto.ts
import { CreateLeaveRequestDto } from './CreateLeaveRequestDto';

export class UpdateLeaveRequestDto extends CreateLeaveRequestDto {}
