// src/dtos/UpdatePaymentMethodDto.ts
import { CreatePaymentMethodDto } from './CreatePaymentMethodDto';

export class UpdatePaymentMethodDto extends CreatePaymentMethodDto {}