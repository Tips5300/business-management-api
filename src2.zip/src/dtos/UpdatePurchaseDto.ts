// src/dtos/UpdatePurchaseDto.ts
import { CreatePurchaseDto } from './CreatePurchaseDto';

export class UpdatePurchaseDto extends CreatePurchaseDto {}
