// src/dtos/UpdatePurchaseProductDto.ts
import { CreatePurchaseProductDto } from './CreatePurchaseProductDto';

export class UpdatePurchaseProductDto extends CreatePurchaseProductDto {}
