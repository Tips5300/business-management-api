// src/dtos/UpdateSaleProductDto.ts
import { CreateSaleProductDto } from './CreateSaleProductDto';

export class UpdateSaleProductDto extends CreateSaleProductDto {}
