// src/dtos/UpdateStockAdjustmentDto.ts
import { CreateStockAdjustmentDto } from './CreateStockAdjustmentDto';

export class UpdateStockAdjustmentDto extends CreateStockAdjustmentDto {}
