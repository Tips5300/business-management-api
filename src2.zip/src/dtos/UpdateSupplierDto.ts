// src/dtos/UpdateSupplierDto.ts
import { CreateSupplierDto } from './CreateSupplierDto';

export class UpdateSupplierDto extends CreateSupplierDto {}
