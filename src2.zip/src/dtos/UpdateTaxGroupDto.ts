// src/dtos/UpdateTaxGroupDto.ts
import { CreateTaxGroupDto } from './CreateTaxGroupDto';

export class UpdateTaxGroupDto extends CreateTaxGroupDto {}
