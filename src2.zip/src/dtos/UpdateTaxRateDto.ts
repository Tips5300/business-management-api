// src/dtos/UpdateTaxRateDto.ts
import { CreateTaxRateDto } from './CreateTaxRateDto';

export class UpdateTaxRateDto extends CreateTaxRateDto {}
